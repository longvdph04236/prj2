<?php
/* @var $this yii\web\View */
$this->params['breadcrumbs'][] = ['label' => 'Hồ sơ người dùng', 'url' => ['index']];
?>
<h1>user/index</h1>

<?= $_SERVER['PHP_SELF']?>